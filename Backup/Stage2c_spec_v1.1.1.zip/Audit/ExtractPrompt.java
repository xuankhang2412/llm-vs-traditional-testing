import java.nio.file.*;
import java.util.*;

public class ExtractPrompt {
    public static void main(String[] args) throws Exception {
        List<String> lines = Files.readAllLines(Paths.get("C:/Users/ACER/.gemini/antigravity/brain/16f15421-0cc9-457f-823b-1eef972099b2/.system_generated/logs/transcript_full.jsonl"));
        for (int i = lines.size() - 1; i >= 0; i--) {
            String l = lines.get(i);
            if (l.contains("\"type\":\"USER_INPUT\"")) {
                int contentIdx = l.indexOf("\"content\":");
                if (contentIdx != -1) {
                    System.out.println(l.substring(contentIdx));
                }
                break;
            }
        }
    }
}
